import java.util.ArrayList;
import java.util.Scanner;
class Expense {
    private String description;
    private double amount;
    
    public Expense(String description, double amount) {
        this.description = description;
        this.amount = amount;
    }
    
    public String getDescription() {
        return description;
    }
    
    public double getAmount() {
        return amount;
    }
    
    @Override
    public String toString() {
        return description + ": $" + amount;
    }
}

public class ExpenseTracker {
    private ArrayList<Expense> expenses;
    
    public ExpenseTracker() {
        expenses = new ArrayList<>();
    }
    
    // Method to add a new expense
    public void addExpense(String description, double amount) {
        expenses.add(new Expense(description, amount));
    }
    
    // Method to view all expenses
    public void viewExpenses() {
        if (expenses.isEmpty()) {
            System.out.println("No expenses recorded.");
        } else {
            System.out.println("Expenses: ");
            for (Expense expense : expenses) {
                System.out.println(expense);
            }
        }
    }
    
    // Method to calculate the total of all expenses
    public double getTotalExpenses() {
        double total = 0.0;
        for (Expense expense : expenses) {
            total += expense.getAmount();
        }
        return total;
    }
    
    // Method to remove an expense
    public void removeExpense(int index) {
        if (index >= 0 && index < expenses.size()) {
            expenses.remove(index);
            System.out.println("Expense removed successfully.");
        } else {
            System.out.println("Invalid index.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExpenseTracker tracker = new ExpenseTracker();
        
        while (true) {
            System.out.println("\n--- Expense Tracker ---");
            System.out.println("1. Add Expense");
            System.out.println("2. View Expenses");
            System.out.println("3. Remove Expense");
            System.out.println("4. View Total Expenses");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline character
            
            switch (choice) {
                case 1:
                    System.out.print("Enter expense description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter amount: ");
                    double amount = scanner.nextDouble();
                    tracker.addExpense(description, amount);
                    System.out.println("Expense added.");
                    break;
                    
                case 2:
                    tracker.viewExpenses();
                    break;
                    
                case 3:
                    System.out.print("Enter the index of the expense to remove: ");
                    int index = scanner.nextInt();
                    tracker.removeExpense(index);
                    break;
                    
                case 4:
                    System.out.println("Total Expenses: $" + tracker.getTotalExpenses());
                    break;
                    
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                    
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

